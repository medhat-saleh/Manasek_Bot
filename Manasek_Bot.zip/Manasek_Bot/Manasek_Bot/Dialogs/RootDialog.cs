﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
  

namespace Manasek_Bot.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {

            var activity = await result as Activity;

            
            // calculate something for us to return
           // int length = (activity.Text ?? string.Empty).Length;

            // return our reply to the user
            //await context.PostAsync($"You sent {activity.Text} which was {length} characters");

            context.Wait(MessageReceivedAsync);

            if (activity.Text == "السلام عليكم")
            {
                await context.PostAsync($"وعليكم السلام ورحمه الله وبركاته");
                await context.PostAsync($"اهلا بك في مناسك بوت");
                
            }
            else if (activity.Text == "على من يجب الحج؟")
            {
                await context.PostAsync($"يجب الحج على كل مسلم بالغ عاقل حر مستطيع");
            }
            else if (activity.Text == "اذكر أركان الحج؟")
            {
                await context.PostAsync($" أركان الحج أربعة وهي : (1) الإحرام  (2) والوقوف بعرفة (3) وطواف الإفاضة (4) والسعي بين الصفا والمروه");
            }
            else if(activity.Text == "ما عدد اركان الاسلام؟")
            {
                await context.PostAsync($"خمس اركان اشهد ان لاااله الا الله .......واقامه الصلاه");
            }
            else
            {
                await context.PostAsync($"enter your question");
            }
              
            
        }
    }
}