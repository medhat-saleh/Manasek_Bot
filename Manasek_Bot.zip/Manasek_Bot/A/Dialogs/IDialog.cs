﻿namespace A.Dialogs
{
    public interface IDialog<T>
    {
    }
}