﻿namespace A.Dialogs
{
    public interface IDialogContext
    {
    }
}