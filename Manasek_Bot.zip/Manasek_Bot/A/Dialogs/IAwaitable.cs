﻿namespace A.Dialogs
{
    internal interface IAwaitable<T>
    {
    }
}